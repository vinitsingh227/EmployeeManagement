﻿using System;

namespace EmployeeManagement.DataAccess
{
    public class Class1
    {
    }
}
